<?php

$token = /*"7175604870:AAGIHamo3LBXydv6wc2RRrLRQVWpLUK_Z5c";*/"6106886084:AAFSJaHH3zuDW1S0mhe3qllZzOZRb1waX_c";

$admin = 1834957586;
$botu = "otps_bypass_bot";
//$apif = json_decode(file_get_contents("api.json"),true)["fsms"];
$fapi = "bfab627255b7ca21f31622d3c6ca8e47";//file_get_contents("https://fastsms.su/stubs/handler_api.php?api_key=$apif&action=getBalance") == null || explode(':',file_get_contents("https://fastsms.su/stubs/handler_api.php?api_key=$apif&action=getBalance"))[1] < 100?"bfab627255b7ca21f31622d3c6ca8e47":$apif;/*"7ff5aab0fd2e41ccaa4065fd017b99a1";*/;
$mid = $mid2 = "bKFyDF08479060984179";
$pid = "LZIUxu86768493680128";
$mname = "Rajesh Kumar";
$sqr = false;
$upi = "1vv9to22gx";
$sd = "5sim.net";//don't change
$mdepo = 10;
$dtax = 5;
$mapi = "2GkvkRZAaKX-yQMFD1J0fPuLbOBQFvDs";
$md = "api.sms-man.com";
$nd = "api.sms-activate.org";
$napi = "fd5e13Be1d9365fB011996fe3f0fc595";
$sapi = "eyJhbGciOiJSUzUxMiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3Mjc1MzkwNjgsImlhdCI6MTY5NjAwMzA2OCwicmF5IjoiYmQ5OGQzNjU5NDM2MjdmNzRiMTFkYTU4YzI1MWViOTAiLCJzdWIiOjE4OTUxMjN9.xVtRK51vMFB3CYUdPhe_digaH0kaPAAAq15kDo6VqsdmaWulo-EmAGMyFfiwGaRpsBGYThw8A7RWD5_opyEyerTvGBDylfjPvjd4SLB-FnKNpsi69QUpHBTqXh7W-yQFCAfVeR_scTWCIBkTqOj6vLwcO77py0jhEY_qG-83089mDBLUKTXsBoAqreHhB8X6TrDhhsPQ5TWQjc-KlxGv_UJ9vU42knzvIiLWtnapYr4sTvlsfNETkZT3sUpPE1Fi4w0qVCskkslCxUoGaj7P9djD2cewL_Fi9Xkg2azsfb5P5FEXl4cQggjwWMrBqxC97td1x63Nhq3gCZfYRsz2hQ";
$channel = "otp_kinger";
$pchannel = "pay_ch7";//Payment channel 
$trx = "TANu8kFLfQ3n7pTwweW7anghQVMYtbhqDW";
$qr = "https://graph.org/file/724798916f37cc76b7b.jpg";
$support = "abhishek71599";
$schannel = "";
$site = "otpbypass.shop/pass2y";
$path = "https://otpbypass.shop/pass2y/paytm/index.php";//"https://api.projectoid.site/v1/telegram/paytm/";
$ma = false;
$btype = "bypass";
$redirect = /*"https://earnwithadarsh.online/pass2y/main.php";*/"https://otpbypass.shop/pass2y/main.php";
?>